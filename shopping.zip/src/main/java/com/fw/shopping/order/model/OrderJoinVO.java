package com.fw.shopping.order.model;

import java.util.Date;

public class OrderJoinVO {

	private String orderId;
	private Date orderRegDate;
	private Integer orderPrice;
	
	private Integer orderDetailNo; 
	private Integer orderStock;
	private Integer deliveryStatus;
	private Integer orderStatus;
	private Long invoiceNo;
	
	private Integer gdsNo;
	private String gdsName;
	private Integer gdsPrice;
	
	private Integer optionNo;
	private String optionName;
	private Integer optionAddPrice;
	
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public Date getOrderRegDate() {
		return orderRegDate;
	}
	public void setOrderRegDate(Date orderRegDate) {
		this.orderRegDate = orderRegDate;
	}
	public Integer getOrderPrice() {
		return orderPrice;
	}
	public void setOrderPrice(Integer orderPrice) {
		this.orderPrice = orderPrice;
	}
	public Integer getOrderDetailNo() {
		return orderDetailNo;
	}
	public void setOrderDetailNo(Integer orderDetailNo) {
		this.orderDetailNo = orderDetailNo;
	}
	public Integer getOrderStock() {
		return orderStock;
	}
	public void setOrderStock(Integer orderStock) {
		this.orderStock = orderStock;
	}
	public Integer getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(Integer deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public Integer getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(Integer orderStatus) {
		this.orderStatus = orderStatus;
	}
	public Long getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(Long invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public Integer getGdsNo() {
		return gdsNo;
	}
	public void setGdsNo(Integer gdsNo) {
		this.gdsNo = gdsNo;
	}
	public String getGdsName() {
		return gdsName;
	}
	public void setGdsName(String gdsName) {
		this.gdsName = gdsName;
	}
	public Integer getGdsPrice() {
		return gdsPrice;
	}
	public void setGdsPrice(Integer gdsPrice) {
		this.gdsPrice = gdsPrice;
	}
	public Integer getOptionNo() {
		return optionNo;
	}
	public void setOptionNo(Integer optionNo) {
		this.optionNo = optionNo;
	}
	public String getOptionName() {
		return optionName;
	}
	public void setOptionName(String optionName) {
		this.optionName = optionName;
	}
	public Integer getOptionAddPrice() {
		return optionAddPrice;
	}
	public void setOptionAddPrice(Integer optionAddPrice) {
		this.optionAddPrice = optionAddPrice;
	}
	@Override
	public String toString() {
		return "OrderJoinVO [orderId=" + orderId + ", orderRegDate=" + orderRegDate + ", orderPrice=" + orderPrice
				+ ", orderDetailNo=" + orderDetailNo + ", orderStock=" + orderStock + ", deliveryStatus="
				+ deliveryStatus + ", orderStatus=" + orderStatus + ", invoiceNo=" + invoiceNo + ", gdsNo=" + gdsNo
				+ ", gdsName=" + gdsName + ", gdsPrice=" + gdsPrice + ", optionNo=" + optionNo + ", optionName="
				+ optionName + ", optionAddPrice=" + optionAddPrice + "]";
	}
	
	
	
	
	
}
