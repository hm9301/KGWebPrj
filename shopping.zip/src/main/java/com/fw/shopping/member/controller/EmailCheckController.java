package com.fw.shopping.member.controller;

import java.util.Random;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmailCheckController {
	
	@Autowired
	JavaMailSender mailSender;
	
	
	@PostMapping("/sendEmail")
	public String sendEmail(HttpSession session, @RequestBody String userEmail) {
		
		String result = null;
		System.out.println("email :" + userEmail);
		
		Random r = new Random();
		int dice = r.nextInt(99999)+100000;
		
		System.out.println("인증번호 :" + dice);
			
		String setfrom = "KGWebPj2020@gmail.com";
		String setto = userEmail;
		String settitle = "F/F 쇼핑몰 이메일 인증번호 입니다.";
		String setcontent = 
				"안녕하세요. F/F 쇼핑몰 인증 센터입니다."
				+System.getProperty("line.separator")
				+"인증 번호는 :"+dice+"입니다"
				+System.getProperty("line.separator")
				+"인증 번호 확인란에 작성해주십시오.";
		
		System.out.println("FROM : "+ setfrom);
		System.out.println("TO :"+ setto);
		
		try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper messageHelper = new MimeMessageHelper(message,
                    true, "UTF-8");
            
            messageHelper.setFrom(setfrom); // 보내는사람 생략하면 정상작동을 안함
            messageHelper.setTo(setto); // 받는사람 이메일
            messageHelper.setSubject(settitle); // 메일제목은 생략이 가능하다
            messageHelper.setText(setcontent); // 메일 내용
            
            mailSender.send(message);
            	
        session.setAttribute("dice", dice);
        
        System.out.println("dice : "+ dice);

        
        result = "sendSuccess";
        
		} catch (Exception e) {
            System.out.println(e);
        }
		
		return result;
	}
	
	@PostMapping("/checkEmail")
	public String checkEmail(@RequestBody int checkEmail, HttpSession session) {
		String result = null;
		
		int dice = (Integer)session.getAttribute("dice");
		System.out.println("dice : " + dice);
		
		if(checkEmail == dice) {
			result = "checkSuccess";
		}
		
		return result;
	}
}
