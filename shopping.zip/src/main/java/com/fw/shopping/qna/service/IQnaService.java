package com.fw.shopping.qna.service;

import java.util.List;

import com.fw.shopping.commons.SearchVO;
import com.fw.shopping.qna.model.QnaVO;

public interface IQnaService {

	List<QnaVO> getQnaList(int gdsNo);
	
	List<QnaVO> getReQnaList(int gdsNo);
	
	List<QnaVO> getMyQnaList(int userNo);
	
	List<QnaVO> getMyReQnaList(int qnaNo);
	
	QnaVO getQnaInfo(int qnaNo);
	
	void addQna(QnaVO qna);
	
	void modifyQna(QnaVO qna);
	
	void deleteQna(int qnaNo);

	String getMemberName(int reviewNo);
	
	List<QnaVO> getAdminQnaList(SearchVO search); //관리자가 확인해야할 qna리스트
	
	//위의 리스트 데이터 수
	int countQna(SearchVO search);
}
