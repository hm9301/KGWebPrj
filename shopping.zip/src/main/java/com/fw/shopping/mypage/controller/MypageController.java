package com.fw.shopping.mypage.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fw.shopping.commons.FileUploadService;
import com.fw.shopping.member.model.MemberVO;
import com.fw.shopping.order.model.OrderDetailVO;
import com.fw.shopping.order.model.OrderJoinVO;
import com.fw.shopping.order.model.OrderVO;
import com.fw.shopping.order.service.IOrderService;
import com.fw.shopping.qna.model.QnaVO;
import com.fw.shopping.qna.service.IQnaService;
import com.fw.shopping.review.model.ReviewVO;
import com.fw.shopping.review.service.IReviewService;

@Controller
@RequestMapping("/mypage")
public class MypageController {

	@Autowired
	private IReviewService reviewService;
	@Autowired
	private IQnaService qnaService;
	@Autowired
	private IOrderService orderService;
	@Autowired
	private FileUploadService fileService;

	
	
	//목록 출력
	@GetMapping
	public String mypage() {
		return "mypage/mypage";
	}
	

	////////////////////////////////<리뷰>/////////////////////////////////////////
	//리뷰 목록 보기
	@GetMapping("/review/list")
	public String reviewList(ReviewVO review, Model model, HttpSession session) {
		
		MemberVO member = (MemberVO)session.getAttribute("user");
		List<ReviewVO> reviewList = new ArrayList<>();
		
		System.out.println("test : " +member);

		Integer userNo = member.getUserNo();
		reviewList = reviewService.getMyReviewList(userNo);
		model.addAttribute("list", reviewList);
		
		return "mypage/reviewList";
	}
	
	
	//리뷰 상세 보기
	@GetMapping("/review/{reviewNo}")
	public String reviewCon(@PathVariable Integer reviewNo, Model model) {
		System.out.println("parameter(글 번호): " + reviewNo);
		
		ReviewVO review = reviewService.getReviewInfo(reviewNo);
		List<ReviewVO> rMReList = reviewService.getMyReReviewList(reviewNo);
		
		System.out.println("Result Data: " + review);
		System.out.println("rMReList: " + rMReList);
		
		model.addAttribute("rev", review)
			.addAttribute("replyList", rMReList)
			.addAttribute("flag", "detail"); //상세보기 요청 지표 
		
		return "mypage/reviewCon";
	}
	
	//리뷰 수정 요청
	@PostMapping("/review/modify")
	public String reviewModify(ReviewVO review, @RequestParam("revImg") MultipartFile revImg) {
		
		System.out.println("리뷰객체:"+ review);
		String reviewImg = fileService.restore(revImg);
		review.setReviewImg(reviewImg);
		
		reviewService.modifyReview(review);

		return "redirect:/mypage/review/"+review.getReviewNo();
	}
	
	//리뷰 삭제 요청
	@PostMapping("/review/delete")
	public String reviewDelete(ReviewVO review) {
		
		System.out.println(review);
		reviewService.deleteReview(review.getReviewNo());
		return "redirect:/mypage/review/list";
	}
	/////////////////////////////////////////</리뷰>//////////////////////////////////////////
	
	
	///////////////<Qna>///////////////////
	//QnA 목록 보기
	@GetMapping("/qna/list")
	public String qnaList(QnaVO qna, Model model, HttpSession session) {
		MemberVO member = (MemberVO)session.getAttribute("user");
		List<QnaVO> qnaList = new ArrayList<>();
		
		System.out.println("test : " +member);

		Integer userNo = member.getUserNo();
		qnaList = qnaService.getMyQnaList(userNo);

		System.out.println("qnaList : " + qnaList);
		model.addAttribute("list", qnaList);
		return "mypage/qnaList";
	}

	
	//QnA 상세 보기
	@GetMapping("/qna/{qnaNo}")
	public String qnaCon(@PathVariable Integer qnaNo, Model model) {
		System.out.println("parameter(글 번호): " + qnaNo);

		QnaVO qna = qnaService.getQnaInfo(qnaNo);
		List<QnaVO> qMReList = qnaService.getMyReQnaList(qnaNo);
				
		System.out.println("Result Data: " + qna);
		System.out.println("qMReList : " + qMReList);

		model.addAttribute("qna", qna);
		model.addAttribute("qMReList", qMReList);

		return "mypage/qnaCon";
	}	
	
	
	//QnA 수정 요청
	@PostMapping("/qna/modify")
	public String qnaModify(QnaVO qna) {
		System.out.println("수정 qna"+qna);
		qnaService.modifyQna(qna);
		return "redirect:/mypage/qna/"+qna.getQnaNo();
	}
	
	//QNA 삭제 요청
	@PostMapping("/qna/delete")
	public String qnaDelete(QnaVO qna) {
		
		System.out.println(qna);
		qnaService.deleteQna(qna.getQnaNo());
		return "redirect:/mypage/qna/list";
	}
	
	////////////</Qna>///////////////////
	
	///////////<Order>/////////////////////	
	//주문 목록 보기
	@GetMapping("/order/list")
	public String orderList(Model model, HttpSession session) {
		
		MemberVO member = (MemberVO)session.getAttribute("user");
		List<OrderJoinVO> orderList = orderService.getMyOrderList(member.getUserNo());
		
		
		for(OrderJoinVO order : orderList) {
			System.out.println(order);
		}
		
		model.addAttribute("orderList", orderList);
		return "mypage/orderList";
	}
	
	//취소, 교환, 환불 요청
	@PostMapping("/order/request")
	public String orderList(OrderJoinVO odd, RedirectAttributes ra) {
		System.out.println("OrderDetailNo:"+odd.getOrderDetailNo());
		System.out.println("OrderStatus:"+odd.getOrderStatus());
		orderService.orderStatus(odd);
		
		return "redirect:/mypage/order/list";
	}
	

	
}
