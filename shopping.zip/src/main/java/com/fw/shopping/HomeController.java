package com.fw.shopping;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.fw.shopping.category.model.CategoryVO;
import com.fw.shopping.category.service.ICategoryService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	public static List<CategoryVO> cate;
	public static List<CategoryVO> subcate;
	@Autowired
	private ICategoryService service;
	
	@GetMapping("/")
	public String home(HttpSession session) {
		if(cate == null) {
			cate = service.getSupCateList();
		}
		if(subcate == null) {
			subcate = service.getSubCateList();
		}
		
		return "home";
	}
	
	@GetMapping("/admin")
	public String admin() {
		return "admin/adminMain";
	}
	
}
