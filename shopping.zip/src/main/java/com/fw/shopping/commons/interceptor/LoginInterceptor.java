package com.fw.shopping.commons.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.fw.shopping.member.model.MemberVO;

public class LoginInterceptor extends HandlerInterceptorAdapter{
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		System.out.println("회원기능 인터셉터 preHandle 메서드");
		HttpSession session = request.getSession();
		
		MemberVO member = (MemberVO)session.getAttribute("user");
		
		if(member == null) {
			System.out.println("멤버가 아닙니다.");
			response.sendRedirect("/shopping");
			session.setAttribute("level", "nonMember");
			return false;
		}
		return true;
	}

}
