package com.fw.shopping.admin.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fw.shopping.commons.PageCreator;
import com.fw.shopping.commons.SearchVO;
import com.fw.shopping.qna.model.QnaVO;
import com.fw.shopping.qna.service.IQnaService;

@Controller
@RequestMapping("/admin/qnas")
public class AdminQnaController {
	
	
	@Inject
	IQnaService qnaService;
	
	//QNA관리 페이지 연결
	@GetMapping
	public String qnaPage(Model model, SearchVO search) {
		
		search.setSort("waitingQ");
		
		PageCreator pc = new PageCreator();
		pc.setPaging(search);
		
		List<QnaVO> list = qnaService.getAdminQnaList(search);
		pc.setTotalCount(qnaService.countQna(search));
		
		System.out.println("list:" + list);
		model.addAttribute("list", list)
			.addAttribute("pc", pc);
		return "admin/qna/list";
	}
	
	//QNA 답변 페이지 호출
	@GetMapping("/{qnaNo}")
	public String answerPage(@PathVariable("qnaNo") int qnaNo, Model model) {
		model.addAttribute("q", qnaService.getQnaInfo(qnaNo));
		return "admin/qna/answer";
	}
	
	//QNA 답변
	@PostMapping("/answer")
	public String answer(QnaVO answer, RedirectAttributes ra) {
		System.out.println(answer);
		qnaService.addQna(answer);
		ra.addFlashAttribute("msg", "answerSuccess");
		return "redirect:/qna/qnas";	
	}
	

}
